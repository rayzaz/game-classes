// src/components/MerioQuestionnaire.tsx
import React, { useMemo, useState } from "react";
import "../styles.css";

type Props = {
  assistant?: { name: string; title?: string }; // можно передать "Мерио"
  onCancel?: () => void;   // вернуться назад в диалог
  onFinish?: (data: QuestionnaireData) => void; // когда будете готовы — сюда прилетит анкета
};

export type Spell = {
  name: string;
  castTime: string;  // "1 ход", "2 хода" и т.п.
  radius: string;    // "10 м вперёд, диаметр 2 м" и т.п.
  effect: string;    // "ожог", "щит", "лечение" и т.д.
  duration: string;  // "разово", "3 хода" и т.д.
};

export type QuestionnaireData = {
  // 1) Имя, возраст, происхождение, биография
  name: string;
  age: 13 | 14 | 15;
  birthplace: "Клевер" | "Алмаз" | "Пики" | "Червы";
  race: string; // по умолчанию "человек"
  bio: string;

  // 2) Внешность
  height: string; // см
  weight: string; // кг
  bodyType: "худощавый" | "средний" | "крепкий";
  hairColor: string;
  hairLength: string;
  eyes: string;
  marks: string;

  // 3) Магия (начало пути)
  grimoireReceived: boolean; // всегда true на старте
  manaShotsAllowed: boolean; // выстрелы маны

  // 4) Класс (боевая роль)
  role:
    | "Танки"
    | "Хиллеры"
    | "Бафферы"
    | "Дебафферы"
    | "Дамагеры"
    | "Универсалы"
    | "Призывники"
    | "Контроллеры"
    | "Поддержка"
    | "Специалисты";

  // 5) Природа магии
  elements: string[]; // 1..4

  // 6) Заклинания
  spells: Spell[];
};

const SUITS = ["Клевер", "Алмаз", "Пики", "Червы"] as const;
const BODY = ["худощавый", "средний", "крепкий"] as const;
const ROLES = [
  "Танки",
  "Хиллеры",
  "Бафферы",
  "Дебафферы",
  "Дамагеры",
  "Универсалы",
  "Призывники",
  "Контроллеры",
  "Поддержка",
  "Специалисты",
] as const;
const ELEMENTS = [
  "Вода",
  "Воздух",
  "Земля",
  "Огонь",
  "Свет",
  "Тьма",
  "Жизнь",
  "Пространство",
  "Время",
  "Дикая магия",
];

export default function MerioQuestionnaire({
  assistant = { name: "Мерио", title: "экзаменатор" },
  onCancel,
  onFinish,
}: Props) {
  const [step, setStep] = useState(1);

  const [data, setData] = useState<QuestionnaireData>({
    name: "",
    age: 13,
    birthplace: "Клевер",
    race: "человек",
    bio: "",

    height: "",
    weight: "",
    bodyType: "средний",
    hairColor: "",
    hairLength: "",
    eyes: "",
    marks: "",

    grimoireReceived: true,
    manaShotsAllowed: true,

    role: "Универсалы",

    elements: [],

    spells: [
      { name: "", castTime: "", radius: "", effect: "", duration: "" },
    ],
  });

  const progress = useMemo(() => Math.round(((step - 1) / 7) * 100), [step]);

  // валидация по шагам (минимум, без фанатизма)
  const valid1 =
    data.name.trim().length >= 2 &&
    [13, 14, 15].includes(data.age) &&
    !!data.birthplace &&
    !!data.race;
  const valid2 =
    !!data.height.trim() &&
    !!data.weight.trim() &&
    !!data.bodyType &&
    !!data.hairColor.trim() &&
    !!data.hairLength.trim() &&
    !!data.eyes.trim();
  const valid3 = true; // это вводные — без полей
  const valid4 = !!data.role;
  const valid5 = data.elements.length >= 1 && data.elements.length <= 4;
  const valid6 =
    data.spells.length >= 1 &&
    data.spells.length <= 3 &&
    data.spells.every(
      (s) =>
        s.name.trim() &&
        s.castTime.trim() &&
        s.radius.trim() &&
        s.effect.trim() &&
        s.duration.trim()
    );

  const canNext = [valid1, valid2, valid3, valid4, valid5, valid6][step - 1];

  const Hint: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <div className="asst-bubble" style={{ marginTop: 8 }}>
      <div className="asst-meta">
        {assistant.name}
        {assistant.title ? ` · ${assistant.title}` : ""}
      </div>
      <div className="asst-text">{children}</div>
    </div>
  );

  const Chip: React.FC<{
    on?: boolean;
    children: React.ReactNode;
    onClick?: () => void;
  }> = ({ on, children, onClick }) => (
    <button className={`chip ${on ? "active" : ""}`} onClick={onClick} type="button">
      {children}
    </button>
  );

  const setSpell = (i: number, patch: Partial<Spell>) => {
    setData((d) => {
      const next = [...d.spells];
      next[i] = { ...next[i], ...patch };
      return { ...d, spells: next };
    });
  };

  return (
    <section className="portal-panel">
      <div className="portal-title">Анкета персонажа · шаг {step} из 7</div>

      <div className="portal-progress">
        <div className="portal-progress-bar" style={{ width: `${progress}%` }} />
        <div className="portal-progress-hint">{progress}%</div>
      </div>

      {/* 1) Имя, возраст, происхождение, биография */}
      {step === 1 && (
        <>
          <Hint>
            Имя! Пиши его прямо сейчас, и без глупостей. Возраст — от 13 лет, это
            время, когда ты получаешь гримуар. Если тебе меньше — значит, ты
            ошибся дверью. Место рождения — Клевер, Алмаз, Пики или Червы. В
            биографии расскажи коротко: кто твоя семья, откуда ты родом, чему
            учился… И да, если у тебя редкая магия рода — не забудь упомянуть.
            Всё понял? Заполняй.
          </Hint>

          <label className="form-label">Имя</label>
          <input
            className="input"
            placeholder="Ваше имя"
            value={data.name}
            onChange={(e) => setData({ ...data, name: e.target.value })}
            autoFocus
          />

          <div className="grid" style={{ gap: 10, gridTemplateColumns: "1fr 1fr" }}>
            <div>
              <label className="form-label">Возраст</label>
              <select
                className="input"
                value={data.age}
                onChange={(e) => setData({ ...data, age: Number(e.target.value) as 13|14|15 })}
              >
                <option value={13}>13</option>
                <option value={14}>14</option>
                <option value={15}>15</option>
              </select>
            </div>
            <div>
              <label className="form-label">Место рождения</label>
              <select
                className="input"
                value={data.birthplace}
                onChange={(e) =>
                  setData({
                    ...data,
                    birthplace: e.target.value as QuestionnaireData["birthplace"],
                  })
                }
              >
                {SUITS.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid" style={{ gap: 10, gridTemplateColumns: "1fr 1fr" }}>
            <div>
              <label className="form-label">Раса</label>
              <input
                className="input"
                placeholder="человек"
                value={data.race}
                onChange={(e) => setData({ ...data, race: e.target.value })}
              />
            </div>
          </div>

          <label className="form-label">Краткая биография</label>
          <textarea
            className="input"
            rows={4}
            placeholder="Семья, происхождение, обучение, редкая магия рода (если есть)…"
            value={data.bio}
            onChange={(e) => setData({ ...data, bio: e.target.value })}
          />

          <div className="asst-actions" style={{ marginTop: 12 }}>
            <button className="btn" type="button" onClick={onCancel}>Отмена</button>
            <button className="btn primary" type="button" disabled={!valid1} onClick={() => setStep(2)}>
              Далее
            </button>
          </div>
        </>
      )}

      {/* 2) Внешность */}
      {step === 2 && (
        <>
          <Hint>
            Так, внешний вид. Рост, вес, телосложение — худощавый, средний или
            крепкий. Волосы — цвет и длина. Глаза — цвет. Особые приметы тоже
            укажи: шрамы, отметины… Сделай аккуратно, чтобы экзаменаторы не
            задавали лишних вопросов.
          </Hint>

          <div className="grid" style={{ gap: 10, gridTemplateColumns: "1fr 1fr" }}>
            <div>
              <label className="form-label">Рост (см)</label>
              <input
                className="input"
                placeholder="170"
                value={data.height}
                onChange={(e) => setData({ ...data, height: e.target.value })}
              />
            </div>
            <div>
              <label className="form-label">Вес (кг)</label>
              <input
                className="input"
                placeholder="60"
                value={data.weight}
                onChange={(e) => setData({ ...data, weight: e.target.value })}
              />
            </div>
          </div>

          <label className="form-label">Телосложение</label>
          <div className="chips" style={{ marginBottom: 8 }}>
            {BODY.map((b) => (
              <Chip
                key={b}
                on={data.bodyType === b}
                onClick={() => setData({ ...data, bodyType: b })}
              >
                {b}
              </Chip>
            ))}
          </div>

          <div className="grid" style={{ gap: 10, gridTemplateColumns: "1fr 1fr" }}>
            <div>
              <label className="form-label">Волосы — цвет</label>
              <input
                className="input"
                placeholder="русые / чёрные / белые…"
                value={data.hairColor}
                onChange={(e) => setData({ ...data, hairColor: e.target.value })}
              />
            </div>
            <div>
              <label className="form-label">Волосы — длина</label>
              <input
                className="input"
                placeholder="короткие / средние / длинные…"
                value={data.hairLength}
                onChange={(e) => setData({ ...data, hairLength: e.target.value })}
              />
            </div>
          </div>

          <div className="grid" style={{ gap: 10, gridTemplateColumns: "1fr 1fr" }}>
            <div>
              <label className="form-label">Глаза — цвет</label>
              <input
                className="input"
                placeholder="карие / зелёные…"
                value={data.eyes}
                onChange={(e) => setData({ ...data, eyes: e.target.value })}
              />
            </div>
            <div>
              <label className="form-label">Особые приметы</label>
              <input
                className="input"
                placeholder="шрамы, родинки, татуировки…"
                value={data.marks}
                onChange={(e) => setData({ ...data, marks: e.target.value })}
              />
            </div>
          </div>

          <div className="asst-actions" style={{ marginTop: 12 }}>
            <button className="btn" type="button" onClick={() => setStep(1)}>Назад</button>
            <button className="btn primary" type="button" disabled={!valid2} onClick={() => setStep(3)}>
              Далее
            </button>
          </div>
        </>
      )}

      {/* 3) Магия (начало пути) */}
      {step === 3 && (
        <>
          <Hint>
            Так, к делу. Гримуар получаешь в 13–15 лет. Уровень — новичок.
            Никаких великих заклинаний. На старте доступны выстрелы маны —
            без них дальше не сдвинешься.
          </Hint>

          <div className="grid" style={{ gap: 10, gridTemplateColumns: "1fr 1fr" }}>
            <label className="checkbox">
              <input
                type="checkbox"
                checked={data.grimoireReceived}
                onChange={(e) =>
                  setData({ ...data, grimoireReceived: e.target.checked })
                }
              />
              <span>Гримуар получен</span>
            </label>

            <label className="checkbox">
              <input
                type="checkbox"
                checked={data.manaShotsAllowed}
                onChange={(e) =>
                  setData({ ...data, manaShotsAllowed: e.target.checked })
                }
              />
              <span>Разрешены выстрелы маны</span>
            </label>
          </div>

          <div className="asst-actions" style={{ marginTop: 12 }}>
            <button className="btn" type="button" onClick={() => setStep(2)}>Назад</button>
            <button className="btn primary" type="button" onClick={() => setStep(4)}>
              Далее
            </button>
          </div>
        </>
      )}

      {/* 4) Класс (боевая роль) */}
      {step === 4 && (
        <>
          <Hint>
            Определись, кем ты будешь в бою. Класс — твоя роль. Выбрал — выполняй.
            Ну, так кто ты — щит, меч или подмога?
          </Hint>

          <div className="chips" style={{ flexWrap: "wrap" }}>
            {ROLES.map((r) => (
              <Chip key={r} on={data.role === r} onClick={() => setData({ ...data, role: r })}>
                {r}
              </Chip>
            ))}
          </div>

          <div className="asst-actions" style={{ marginTop: 12 }}>
            <button className="btn" type="button" onClick={() => setStep(3)}>Назад</button>
            <button className="btn primary" type="button" disabled={!valid4} onClick={() => setStep(5)}>
              Далее
            </button>
          </div>
        </>
      )}

      {/* 5) Природа магии */}
      {step === 5 && (
        <>
          <Hint>
            Записывай стихии: от одной до четырёх. Комбинации допустимы —
            Огонь+Земля=Лава, Вода+Воздух=Лёд. Думай быстро и честно.
          </Hint>

          <div className="chips" style={{ flexWrap: "wrap" }}>
            {ELEMENTS.map((el) => {
              const on = data.elements.includes(el);
              const toggle = () => {
                setData((d) => {
                  const has = d.elements.includes(el);
                  if (has) return { ...d, elements: d.elements.filter((x) => x !== el) };
                  if (d.elements.length >= 4) return d; // максимум 4
                  return { ...d, elements: [...d.elements, el] };
                });
              };
              return (
                <Chip key={el} on={on} onClick={toggle}>
                  {el}
                </Chip>
              );
            })}
          </div>
          <div className="portal-subtle" style={{ marginTop: 6 }}>
            выбрано: {data.elements.length} / 4
          </div>

          <div className="asst-actions" style={{ marginTop: 12 }}>
            <button className="btn" type="button" onClick={() => setStep(4)}>Назад</button>
            <button className="btn primary" type="button" disabled={!valid5} onClick={() => setStep(6)}>
              Далее
            </button>
          </div>
        </>
      )}

      {/* 6) Заклинания */}
      {step === 6 && (
        <>
          <Hint>
            Заклинания! На старте 1–3 штуки. Название, время каста, радиус,
            эффект и длительность. Урон считает куб, а не твоё самолюбие.
          </Hint>

          {data.spells.map((s, i) => (
            <div key={i} className="confirm-card" style={{ marginBottom: 10 }}>
              <div className="grid" style={{ gap: 10, gridTemplateColumns: "1fr 1fr" }}>
                <div>
                  <label className="form-label">Название</label>
                  <input
                    className="input"
                    placeholder="Напр. «Стрела маны»"
                    value={s.name}
                    onChange={(e) => setSpell(i, { name: e.target.value })}
                  />
                </div>
                <div>
                  <label className="form-label">Время каста</label>
                  <input
                    className="input"
                    placeholder="Напр. 1 ход"
                    value={s.castTime}
                    onChange={(e) => setSpell(i, { castTime: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid" style={{ gap: 10, gridTemplateColumns: "1fr 1fr" }}>
                <div>
                  <label className="form-label">Радиус / дистанция</label>
                  <input
                    className="input"
                    placeholder="10 м вперёд, диаметр 2 м"
                    value={s.radius}
                    onChange={(e) => setSpell(i, { radius: e.target.value })}
                  />
                </div>
                <div>
                  <label className="form-label">Эффект</label>
                  <input
                    className="input"
                    placeholder="ожог / щит / лечение…"
                    value={s.effect}
                    onChange={(e) => setSpell(i, { effect: e.target.value })}
                  />
                </div>
              </div>

              <label className="form-label">Длительность</label>
              <input
                className="input"
                placeholder="разово / 3 хода…"
                value={s.duration}
                onChange={(e) => setSpell(i, { duration: e.target.value })}
              />

              <div className="asst-actions" style={{ marginTop: 8 }}>
                <button
                  className="btn"
                  type="button"
                  onClick={() =>
                    setData((d) => ({
                      ...d,
                      spells: d.spells.filter((_, idx) => idx !== i),
                    }))
                  }
                  disabled={data.spells.length <= 1}
                  title="Удалить заклинание"
                >
                  Удалить
                </button>
              </div>
            </div>
          ))}

          <div className="asst-actions" style={{ marginTop: 8 }}>
            <button
              className="btn"
              type="button"
              onClick={() =>
                setData((d) =>
                  d.spells.length >= 3
                    ? d
                    : { ...d, spells: [...d.spells, { name: "", castTime: "", radius: "", effect: "", duration: "" }] }
                )
              }
              disabled={data.spells.length >= 3}
            >
              Добавить заклинание
            </button>
          </div>

          <div className="asst-actions" style={{ marginTop: 12 }}>
            <button className="btn" type="button" onClick={() => setStep(5)}>Назад</button>
            <button className="btn primary" type="button" disabled={!valid6} onClick={() => setStep(7)}>
              Далее
            </button>
          </div>
        </>
      )}

      {/* 7) Система боя + неактивная кнопка отправки */}
      {step === 7 && (
        <>
          <Hint>
            Слушай внимательно. Бой решает куб: ты и враг бросаете, к числу
            прибавляются бонусы от класса, магии или предметов. Заклинания
            накладывают эффекты. Итог — куб + бонус + эффект. Побеждает тот, у
            кого больше. Жалобы не принимаются.
          </Hint>

          <div className="portal-subtle" style={{ marginTop: 6 }}>
            Это пояснения. После них в реальной версии появится отправка «совиной почтой».
          </div>

          <div className="asst-actions" style={{ marginTop: 14 }}>
            <button className="btn" type="button" onClick={() => setStep(6)}>Назад</button>
            {/* Некликабельная (disabled) кнопка — каркас под будущую отправку */}
            <button className="btn primary" type="button" disabled title="Скоро!">
              Отправить анкету совиной почтой
            </button>
          </div>
        </>
      )}
    </section>
  );
}
